from kubernetes import client, config
import time

# Kubernetes 클라이언트 구성 로드
config.load_kube_config()

# CoreV1Api 인스턴스 생성
v1 = client.CoreV1Api()

# 모니터링 함수
def monitor_pods():
    while True:
        # 현재 시간 출력
        print(time.strftime('%Y-%m-%d %H:%M:%S'))

        # 기본 네임스페이스의 파드 목록 가져오기
        pods = v1.list_namespaced_pod(namespace='default', watch=False)

        # 파드 정보 출력
        for pod in pods.items:
            print(f"Name: {pod.metadata.name}, Namespace: {pod.metadata.namespace}, "
                  f"Node: {pod.spec.node_name}, IP: {pod.status.pod_ip}, "
                  f"Status: {pod.status.phase}")

        # 0.2초 대기
        time.sleep(0.2)

# 모니터링 시작
monitor_pods()