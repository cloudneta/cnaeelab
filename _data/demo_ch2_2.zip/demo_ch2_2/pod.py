from kubernetes import client, config, watch
import time

# Kubernetes 클라이언트 구성 로드
config.load_kube_config()

# CoreV1Api 인스턴스 생성
v1 = client.CoreV1Api()

# 상태를 보다 상세하게 가져오기 위한 함수
def get_pod_status(pod):
    if pod.metadata.deletion_timestamp:
        return "Terminating"
    for condition in pod.status.conditions or []:
        if condition.type == "PodScheduled" and condition.status == "False":
            return "Pending"
        if condition.type == "Initialized" and condition.status == "False":
            return "Init"
        if condition.type == "Ready" and condition.status == "False":
            return "PodInitializing"
    return pod.status.phase

# 주기적으로 파드 상태를 확인하는 함수
def monitor_pods():
    while True:
        # 현재 시간 출력
        print(time.strftime('%Y-%m-%d %H:%M:%S') + '.%02d' % (time.time() % 1 * 100))

        # 기본 네임스페이스의 파드 목록 가져오기
        pods = v1.list_namespaced_pod(namespace='default', watch=False)

        # 파드 정보 출력
        for pod in pods.items:
            # container_statuses가 None이 아닌지 확인
            if pod.status.container_statuses is not None:
                total_containers = len(pod.status.container_statuses)
                ready_containers = sum(1 for status in pod.status.container_statuses if status.ready)
            else:
                total_containers = 0
                ready_containers = 0

            # 보다 상세한 상태 가져오기
            detailed_status = get_pod_status(pod)

            print(f"Name: {pod.metadata.name}, "
                  f"IP: {pod.status.pod_ip}, "
                  f"Status: {detailed_status}, "
                  f"READY: {ready_containers}/{total_containers}")

        # 0.2초 대기
        time.sleep(0.2)

# watch를 사용한 모니터링 함수
def watch_pods():
    w = watch.Watch()
    for event in w.stream(v1.list_namespaced_pod, namespace='default'):
        pod = event['object']
        event_type = event['type']

        # container_statuses가 None이 아닌지 확인
        if pod.status.container_statuses is not None:
            total_containers = len(pod.status.container_statuses)
            ready_containers = sum(1 for status in pod.status.container_statuses if status.ready)
        else:
            total_containers = 0
            ready_containers = 0

        # 보다 상세한 상태 가져오기
        detailed_status = get_pod_status(pod)

        print(f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}, "
              f"Event: {event_type}, "
              f"Name: {pod.metadata.name}, "
              f"IP: {pod.status.pod_ip}, "
              f"Status: {detailed_status}, "
              f"READY: {ready_containers}/{total_containers}")

# 모니터링 시작
if __name__ == "__main__":
    choice = input("Choose monitoring type (1 for monitor, 2 for watch): ")
    if choice == "1":
        monitor_pods()
    elif choice == "2":
        watch_pods()
    else:
        print("Invalid choice")
