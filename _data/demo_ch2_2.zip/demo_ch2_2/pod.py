from kubernetes import client, config, watch
import time

# Kubernetes 클라이언트 구성 로드
config.load_kube_config()

# CoreV1Api 인스턴스 생성
v1 = client.CoreV1Api()

# 모니터링 함수
def monitor_pods():
    w = watch.Watch()
    for event in w.stream(v1.list_namespaced_pod, namespace='default'):
        pod = event['object']
        event_type = event['type']
        # container_statuses가 None이 아닌지 확인
        if pod.status.container_statuses is not None:
            total_containers = len(pod.status.container_statuses)
            ready_containers = sum(1 for status in pod.status.container_statuses if status.ready)
        else:
            total_containers = 0
            ready_containers = 0

        print(f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}, "
              f"Event: {event_type}, "
              f"Name: {pod.metadata.name}, "
              f"IP: {pod.status.pod_ip}, "
              f"Status: {pod.status.phase}, "
              f"READY: {ready_containers}/{total_containers}")
        
        # 0.2초 대기
        time.sleep(0.2)

# 모니터링 시작
monitor_pods()