import boto3
import time
import os

# 환경 변수에서 AWS 자격 증명 및 설정 읽기
aws_access_key_id = os.getenv('AWS_ACCESS_KEY_ID')
aws_secret_access_key = os.getenv('AWS_SECRET_ACCESS_KEY')
aws_default_region = os.getenv('AWS_DEFAULT_REGION')
target_group_arn = os.getenv('ELB_TG_ARN')

# AWS 세션 설정
session = boto3.Session(
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
    region_name=aws_default_region
)

# ELB 클라이언트 생성
elbv2 = session.client('elbv2')

# 모니터링 함수
def monitor_target_group():
    while True:
        # 현재 시간 출력
        current_time = time.strftime('%Y-%m-%d %H:%M:%S')
        print(current_time)

        # 타겟 그룹 상태 조회
        response = elbv2.describe_target_health(
            TargetGroupArn=target_group_arn
        )

        # 타겟 상태 출력
        for target in response['TargetHealthDescriptions']:
            ip = target['Target']['Id']
            state = target['TargetHealth']['State']
            print(f"IP: {ip}, State: {state}")

        # 0.2초 대기
        time.sleep(0.2)

# 모니터링 시작
monitor_target_group()