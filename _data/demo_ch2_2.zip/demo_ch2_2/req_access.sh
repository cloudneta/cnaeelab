#!/bin/bash

source /tmp/alb_env.sh

output=$(curl -s -H "Cache-Control: no-cache" -w "HTTPCode=%{http_code}_TotalTime=%{time_total}" http://${ALB_ADDR})
http_code_total_time=$(echo "$output" | tail -n 1)
html_content=$(echo "$output" | head -n 1 | grep -oP 'Pod IP is \K[0-9.]+')

echo "$(date)_${http_code_total_time}_PodIP=${html_content}"