#!/bin/bash

source /tmp/alb_env.sh

output=$(curl -s -H "Cache-Control: no-cache" -w "HTTPCode=%{http_code}_TotalTime=%{time_total}" http://${ALB_ADDR})
http_code_total_time=$(echo "$output" | tail -n 1)
html_content=$(echo "$output" | head -n 1 | grep -oP 'Pod IP is \K[0-9.]+')

# 현재 시간을 소수점 두 자리까지 포함하여 출력
current_time=$(date +'%Y-%m-%d %H:%M:%S')
milliseconds=$(printf "%02d" $(echo "$(date +%N) / 10000000" | bc))

echo "${current_time}.${milliseconds}_${http_code_total_time}_PodIP=${html_content}"