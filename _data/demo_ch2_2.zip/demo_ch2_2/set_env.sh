#!/bin/bash

ALB_ADDR=$(kubectl get ingress ingress-demo -o jsonpath={.status.loadBalancer.ingress[0].hostname})
echo "export ALB_ADDR=${ALB_ADDR}" > /tmp/alb_env.sh